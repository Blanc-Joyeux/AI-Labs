import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np


def load_and_preprocess_data():
    # Load the CSV file
    df = pd.read_csv('fashion-mnist_train.csv')  # Change to your actual file path

    # Separate features (pixels) and labels
    X = df.iloc[:, 1:].values
    y = df.iloc[:, 0].values

    # Normalize pixel values
    X = X / 255.0  # Scale pixel values to the range [0, 1]

    # Reshape X to have a shape (num_samples, 28, 28, 1)
    X = X.reshape(-1, 28, 28, 1)

    # Convert labels to categorical
    y = to_categorical(y, 10)  # Assuming there are 10 classes

    # Split into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    return (X_train, y_train), (X_test, y_test)


def create_model():
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Flatten(),
        Dense(64, activation='relu'),
        Dense(10, activation='softmax')  # Update the number of output neurons based on your classes
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model


# Load and preprocess the data from the CSV
(train_data, train_labels), (test_data, test_labels) = load_and_preprocess_data()

# Create the model
model = create_model()

# Train the model
model.fit(train_data, train_labels, epochs=5, validation_data=(test_data, test_labels))

# Save the model
model.save('custom_model.h5')  # Save the trained model
