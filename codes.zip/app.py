from flask import Flask, request, render_template
import tensorflow as tf
import numpy as np
import cv2
from tensorflow.keras.models import load_model

app = Flask(__name__)
model = load_model('custom_model.h5')

# Define the human-readable class names
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        file = request.files['image']
        img = cv2.imdecode(np.fromstring(file.read(), np.uint8), 1)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Convert to grayscale if needed
        img = cv2.resize(img, (28, 28)) / 255.0  # Resize to match the model input size
        img = img.reshape(1, 28, 28, 1)  # Reshape for the CNN input

        predictions = model.predict(img)
        predicted_class = np.argmax(predictions, axis=1)  # Get the predicted class index
        predicted_class_name = class_names[predicted_class[0]]  # Map the index to class name
        confidence = predictions[0][predicted_class[0]]  # Get the confidence of the prediction

        # Convert confidence to a scalar value if necessary
        confidence_value = float(confidence)

        return render_template('index.html',
                               prediction=f'Predicted class: {predicted_class_name}, Confidence: {confidence_value:.4f}')

if __name__ == '__main__':
    app.run(debug=True)
