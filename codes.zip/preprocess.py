import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator

def load_and_preprocess_data():
    # Provide the path to your custom dataset
    train_dir = 'fashion-mnist_train.csv'
    test_dir = 'fashion-mnist_test.csv'

    # Use ImageDataGenerator for preprocessing and augmentation
    train_datagen = ImageDataGenerator(rescale=1./255)
    test_datagen = ImageDataGenerator(rescale=1./255)

    train_data = train_datagen.flow_from_directory(
        train_dir,
        target_size=(28, 28),
        batch_size=32,
        class_mode='categorical',
        color_mode='grayscale'  # Use grayscale if your images are in grayscale
    )

    test_data = test_datagen.flow_from_directory(
        test_dir,
        target_size=(28, 28),
        batch_size=32,
        class_mode='categorical',
        color_mode='grayscale'  # Use grayscale if your images are in grayscale
    )

    return train_data, test_data

train_data, test_data = load_and_preprocess_data()
